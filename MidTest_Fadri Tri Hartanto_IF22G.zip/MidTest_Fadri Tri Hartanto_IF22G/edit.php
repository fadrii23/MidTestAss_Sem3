<?php
include_once("./config/db.php");
// Tampilkan data produk yang dipilih berdasarkan id
// Dapatkan id dari URL
$id = $_GET['id'];

// Ambil data produk berdasarkan id
$result = mysqli_query($db_connect, "SELECT * FROM products WHERE id=$id");

while ($user_data = mysqli_fetch_array($result)) {
    $name = $user_data['name'];
    $price = $user_data['price'];
    $image = $user_data['image'];
}
?>

<html>

<head>
    <title>Edit Data</title>
</head>

<body>
    <a href="index.php">Beranda</a> | <a href="show.php">Lihat Produk</a> | <a href="logout.php">Logout</a>
    <br /><br />

    <form name="form1" method="post" action="./backend/edit.php">
        <table border="0">
            <tr>
                <td>Nama</td>
                <td><input type="text" name="name" value="<?php echo $name; ?>"></td>
            </tr>
            <tr>
                <td>Harga</td>
                <td><input type="text" name="price" value="<?php echo $price; ?>"></td>
            </tr>
            <tr>
                <td>Gambar</td>
                <td><input type="text" name="image" value="<?php echo $image; ?>"></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value="<?php echo $id; ?>"></td>
                <td><button type="submit" name="update">Update</button></td>
            </tr>
        </table>
    </form>
</body>

</html>